const http=require("http"),fs=require("fs"),path=require("path");
const PORT=3000;
function json(res,obj,status=200){res.writeHead(status,{"Content-Type":"application/json; charset=utf-8","Access-Control-Allow-Origin":"*"});res.end(JSON.stringify(obj));}
async function build(prompt){
 const key=process.env.OPENAI_API_KEY;
 if(!key) return "الخادم جاهز، لكن لم يتم ضبط OPENAI_API_KEY بعد. ضع مفتاح API كمتغير بيئة ثم أعد تشغيل الخادم.";
 const body={model:process.env.OPENAI_MODEL||"gpt-5.6-mini",input:[
 {role:"system",content:"أنت مدير استوديو ألعاب. حلل فكرة المستخدم إلى مواصفات لعبة قابلة للتنفيذ. قسّم العمل منطقيًا إلى أكثر من 100 دور متخصص، لكن لا تدّع أن 100 نموذج مستقل يعمل فعليًا. ركّز على Unity 3D، وأنشئ خطة ملفات ومكونات ومراحل اختبار. أجب بالعربية."},
 {role:"user",content:prompt}]};
 const r=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Content-Type":"application/json","Authorization":"Bearer "+key},body:JSON.stringify(body)});
 const j=await r.json();
 if(!r.ok) return "خطأ API: "+(j.error?.message||JSON.stringify(j));
 return j.output_text||JSON.stringify(j);
}
const server=http.createServer(async(req,res)=>{
 if(req.method==="POST"&&req.url==="/api/build"){
  let d="";req.on("data",x=>d+=x);req.on("end",async()=>{try{let p=JSON.parse(d).prompt||"";json(res,{answer:await build(p)})}catch(e){json(res,{error:e.message},500)}});return;
 }
 let f=req.url==="/"?"index.html":req.url.slice(1);let file=path.join(__dirname,"public",f);
 fs.readFile(file,(e,data)=>{if(e){res.writeHead(404);res.end("Not found")}else{res.writeHead(200,{"Content-Type":f.endsWith(".js")?"text/javascript":"text/html; charset=utf-8"});res.end(data)}});
});
server.listen(PORT,()=>console.log("AI Game Studio: http://localhost:"+PORT));
